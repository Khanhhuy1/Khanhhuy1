import {Information} from "../../components";
import React from "react";

const InformationPage = () => {
    return <Information />;
};

export default InformationPage;
