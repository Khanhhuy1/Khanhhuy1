import Information from "./Information";

export {Information};
