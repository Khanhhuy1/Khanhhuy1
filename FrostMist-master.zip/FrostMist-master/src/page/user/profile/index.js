import React from "react";
import {Profile} from "../../../components";

const index = () => {
    return <Profile />;
};

export default index;
