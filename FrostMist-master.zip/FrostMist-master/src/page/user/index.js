import Profile from "./profile";
import UpdateProfile from "./UpdateProfile";

export {Profile, UpdateProfile};
