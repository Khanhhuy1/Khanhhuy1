import React from "react";
import {Messenger} from "../../../components";

const index = () => {
    return <Messenger />;
};

export default index;
